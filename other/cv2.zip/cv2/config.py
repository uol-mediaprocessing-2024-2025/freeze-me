import os

BINARIES_PATHS = [
    os.path.join(os.path.join(LOADER_DIR, '../../'), 'x64/vc14/bin'),
    os.path.join(os.getenv('CUDA_PATH', 'D:/NVIDIA/CUDA/12.4'), 'bin')
] + BINARIES_PATHS
